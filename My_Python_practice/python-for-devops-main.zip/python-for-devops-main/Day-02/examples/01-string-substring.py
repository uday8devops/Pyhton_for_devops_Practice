text = "Python is awesome"
substring = "is"
if substring in text:
    print(substring, "found in the text")
