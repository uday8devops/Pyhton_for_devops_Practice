text = "Python is awesome"
words = text.split()
print("Words:", words)
